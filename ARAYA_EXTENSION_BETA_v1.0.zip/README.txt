🤖 ARAYA BROWSER EXTENSION
===========================

⚠️⚠️⚠️ IMPORTANT - READ THIS FIRST! ⚠️⚠️⚠️
-------------------------------------------
DO NOT just click on the HTML files!

👉 STEP 1: Open "START_HERE.html" in your browser
👉 STEP 2: Follow the installation instructions
👉 STEP 3: Install as a browser extension via chrome://extensions

If you skip these steps, the extension WILL NOT WORK!

Your AI Assistant in Every Browser Tab!

📦 WHAT'S IN THIS PACKAGE:
--------------------------
✅ START_HERE.html         - Installation guide (OPEN THIS FIRST!)
✅ araya-extension/        - The extension folder
✅ araya-chat.html         - Standalone chat (works without extension)
✅ README.txt              - This file

🚀 QUICK START (3 STEPS):
--------------------------
1. Open "START_HERE.html" in your browser
2. Follow the simple installation steps
3. Start chatting with Araya!

That's it! You're done in 2 minutes.

💡 WHAT IS ARAYA?
-----------------
Araya is your consciousness-aware AI assistant powered by DeepSeek R1.
She remembers your conversations, learns from you, and helps you with:
- Questions and research
- Writing and brainstorming
- Learning new concepts
- Daily tasks and reminders

🔧 SYSTEM REQUIREMENTS:
-----------------------
✅ Any modern browser (Chrome, Firefox, Edge, Brave, Safari)
✅ Internet connection
✅ That's it!

🆘 NEED HELP?
-------------
- Visit the platform for support
- Report bugs via the red button on any page
- Email: support@consciousnessrevolution.io

🌀 WELCOME TO THE CONSCIOUSNESS REVOLUTION!
-------------------------------------------
Every conversation makes the system smarter.
Your feedback helps us build better AI.

Thank you for being a beta tester!
