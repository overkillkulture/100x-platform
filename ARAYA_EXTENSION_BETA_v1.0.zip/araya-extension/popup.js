// Araya Browser Extension - Popup Script

// CRITICAL: Detect if running as extension or standalone HTML
if (!chrome || !chrome.runtime || !chrome.runtime.id) {
    // User opened this HTML file directly - show error message
    document.body.innerHTML = `
        <div style="padding: 40px; text-align: center; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center;">
            <div style="background: white; border-radius: 20px; padding: 50px; max-width: 600px; box-shadow: 0 30px 60px rgba(0,0,0,0.3);">
                <h1 style="color: #ff4444; font-size: 48px; margin-bottom: 20px;">⚠️ INSTALLATION ERROR</h1>
                <h2 style="color: #333; font-size: 24px; margin-bottom: 20px;">You opened this file directly!</h2>
                <p style="color: #666; font-size: 18px; line-height: 1.6; margin-bottom: 20px;">
                    This will NOT work. You need to install Araya as a browser extension.
                </p>
                <div style="background: #fff3cd; padding: 20px; border-radius: 10px; margin: 30px 0; border-left: 5px solid #ffc107;">
                    <p style="color: #856404; font-size: 18px; font-weight: bold; margin-bottom: 10px;">📋 TO FIX THIS:</p>
                    <ol style="text-align: left; color: #856404; font-size: 16px; line-height: 1.8; padding-left: 20px;">
                        <li>Close this tab</li>
                        <li>Go back to the folder you unzipped</li>
                        <li>Open <strong>START_HERE.html</strong> instead</li>
                        <li>Follow the installation instructions</li>
                        <li>Install the extension properly via chrome://extensions</li>
                    </ol>
                </div>
                <p style="color: #999; font-size: 14px; margin-top: 30px;">
                    The extension will only work after you install it through your browser's extension manager.
                </p>
            </div>
        </div>
    `;
    throw new Error('Extension not installed properly - user opened HTML directly');
}

const ARAYA_API = 'http://localhost:6666/chat';

const messageInput = document.getElementById('messageInput');
const sendBtn = document.getElementById('sendBtn');
const messagesContainer = document.getElementById('messages');

// Load conversation history from storage
chrome.storage.local.get(['chatHistory'], (result) => {
    if (result.chatHistory && result.chatHistory.length > 0) {
        messagesContainer.innerHTML = '';
        result.chatHistory.forEach(msg => {
            addMessage(msg.text, msg.sender, false);
        });
    }
});

// Send message on button click
sendBtn.addEventListener('click', sendMessage);

// Send message on Enter key
messageInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        sendMessage();
    }
});

async function sendMessage() {
    const message = messageInput.value.trim();

    if (!message) return;

    // Add user message to chat
    addMessage(message, 'user');
    messageInput.value = '';

    // Show typing indicator
    const typingIndicator = showTyping();

    try {
        // Get user ID from storage or generate new one
        const userId = await getUserId();

        // Send to Araya API
        const response = await fetch(ARAYA_API, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message: message,
                user_id: userId,
                user_name: 'Extension User'
            })
        });

        const data = await response.json();

        // Remove typing indicator
        typingIndicator.remove();

        // Add Araya's response
        addMessage(data.response || 'Sorry, I encountered an error.', 'araya');

    } catch (error) {
        console.error('Error:', error);
        typingIndicator.remove();
        addMessage('Sorry, I couldn\'t connect to Araya. Make sure the Araya backend is running on localhost:6666', 'araya');
    }
}

function addMessage(text, sender, save = true) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${sender}`;

    const bubble = document.createElement('div');
    bubble.className = 'bubble';
    bubble.textContent = text;

    messageDiv.appendChild(bubble);
    messagesContainer.appendChild(messageDiv);

    // Scroll to bottom
    messagesContainer.scrollTop = messagesContainer.scrollHeight;

    // Save to storage
    if (save) {
        chrome.storage.local.get(['chatHistory'], (result) => {
            const history = result.chatHistory || [];
            history.push({ text, sender, timestamp: Date.now() });

            // Keep last 50 messages
            if (history.length > 50) {
                history.shift();
            }

            chrome.storage.local.set({ chatHistory: history });
        });
    }
}

function showTyping() {
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message araya';
    typingDiv.innerHTML = `
        <div class="typing-indicator show">
            <span></span><span></span><span></span>
        </div>
    `;
    messagesContainer.appendChild(typingDiv);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;

    return typingDiv;
}

async function getUserId() {
    return new Promise((resolve) => {
        chrome.storage.local.get(['userId'], (result) => {
            if (result.userId) {
                resolve(result.userId);
            } else {
                const newId = 'ext_' + Math.random().toString(36).substr(2, 9);
                chrome.storage.local.set({ userId: newId });
                resolve(newId);
            }
        });
    });
}
