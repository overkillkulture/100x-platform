// Araya Browser Extension - Background Service Worker

// Listen for extension installation
chrome.runtime.onInstalled.addListener(() => {
    console.log('Araya Extension installed!');

    // Set default settings
    chrome.storage.local.set({
        settings: {
            apiUrl: 'http://localhost:6666/chat',
            theme: 'default'
        }
    });
});

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'getApiUrl') {
        chrome.storage.local.get(['settings'], (result) => {
            sendResponse({ apiUrl: result.settings?.apiUrl || 'http://localhost:6666/chat' });
        });
        return true; // Keep channel open for async response
    }
});
