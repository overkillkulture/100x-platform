var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/bug-report.mjs
var bug_report_exports = {};
__export(bug_report_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(bug_report_exports);
var AIRTABLE_TOKEN = "pat8DtOnZ1crQT56g.a83c21fa77ead56a661353b0cd0b286816ca14502ce717c8b247c0c52a326757";
var BASE_ID = "app7F75X1uny6jPfd";
var TABLE_NAME = "Documents";
var handler = async (event, context) => {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const bugData = JSON.parse(event.body);
    const bugReport = {
      ...bugData,
      received_at: (/* @__PURE__ */ new Date()).toISOString(),
      ip: event.headers["x-forwarded-for"] || "unknown",
      userAgent: bugData.userAgent || event.headers["user-agent"] || "unknown"
    };
    console.log("\u{1F41B} BUG REPORT RECEIVED - SAVING TO AIRTABLE \u{1F41B}");
    console.log("Title:", bugReport.title || "N/A");
    console.log("Description:", bugReport.description || "N/A");
    console.log("Reporter:", bugReport.reporter || "Anonymous");
    const bugDetails = `REPORTER: ${bugReport.reporter || "Anonymous"} | DESC: ${bugReport.description || "No description"} | AGENT: ${bugReport.userAgent}`;
    const airtableUrl = `https://api.airtable.com/v0/${BASE_ID}/${TABLE_NAME}`;
    const airtableData = {
      fields: {
        "Filename": `BUG: ${bugReport.title || "Untitled"}`,
        "Path": bugDetails.substring(0, 500),
        // Store bug details in Path field (max 500 chars)
        "Extension": "bug",
        "Category": "bug",
        // Simple category value
        "Size (KB)": bugReport.description ? bugReport.description.length / 1024 : 0,
        "Created": bugReport.timestamp || bugReport.received_at,
        "Modified": bugReport.received_at,
        "Indexed": (/* @__PURE__ */ new Date()).toISOString()
      }
    };
    const airtableResponse = await fetch(airtableUrl, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${AIRTABLE_TOKEN}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(airtableData)
    });
    if (!airtableResponse.ok) {
      const errorText = await airtableResponse.text();
      console.error("Airtable error:", errorText);
      throw new Error(`Airtable failed: ${errorText}`);
    }
    const airtableResult = await airtableResponse.json();
    console.log("\u2705 SAVED TO AIRTABLE:", airtableResult.id);
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type"
      },
      body: JSON.stringify({
        success: true,
        message: "Bug report saved to Airtable",
        id: airtableResult.id
      })
    };
  } catch (error) {
    console.error("Error processing bug report:", error);
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({
        success: false,
        error: error.message
      })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
