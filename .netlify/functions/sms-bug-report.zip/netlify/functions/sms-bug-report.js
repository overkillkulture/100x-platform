var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/sms-bug-report.mjs
var sms_bug_report_exports = {};
__export(sms_bug_report_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(sms_bug_report_exports);
var handler = async (event, context) => {
  console.log("\u{1F4F1} SMS RECEIVED");
  console.log("Full event:", JSON.stringify(event, null, 2));
  try {
    const params = new URLSearchParams(event.body);
    const from = params.get("From");
    const body = params.get("Body");
    const messageSid = params.get("MessageSid");
    console.log(`From: ${from}`);
    console.log(`Message: ${body}`);
    let title = "Bug via SMS";
    let description = body;
    if (body.includes("BUG:") || body.includes("Bug:") || body.includes("bug:")) {
      const lines = body.split("\n");
      const bugLine = lines.find((l) => l.toLowerCase().includes("bug:"));
      if (bugLine) {
        title = bugLine.replace(/bug:/i, "").trim();
      }
      const detailsLine = lines.find((l) => l.toLowerCase().includes("details:"));
      if (detailsLine) {
        description = detailsLine.replace(/details:/i, "").trim();
      } else {
        const titleIndex = lines.findIndex((l) => l.toLowerCase().includes("bug:"));
        if (titleIndex >= 0 && titleIndex < lines.length - 1) {
          description = lines.slice(titleIndex + 1).join("\n").trim();
        }
      }
    }
    console.log("Creating GitHub issue...");
    const githubResponse = await fetch(
      `https://api.github.com/repos/${process.env.GITHUB_REPO}/issues`,
      {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${process.env.GITHUB_TOKEN}`,
          "Accept": "application/vnd.github.v3+json",
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          title: title || "Bug via SMS",
          body: `**Bug reported via SMS**

**From:** ${from}

**Message:**
${description || body}

**Message ID:** ${messageSid}
**Received:** ${(/* @__PURE__ */ new Date()).toISOString()}`
        })
      }
    );
    if (githubResponse.ok) {
      const issue = await githubResponse.json();
      console.log(`\u2705 GitHub issue created: #${issue.number}`);
      const confirmationMessage = `\u2705 Bug received!
Issue #${issue.number} created.
View: ${issue.html_url}

Thank you!`;
      const twilioResponse = await fetch(
        `https://api.twilio.com/2010-04-01/Accounts/${process.env.TWILIO_ACCOUNT_SID}/Messages.json`,
        {
          method: "POST",
          headers: {
            "Authorization": "Basic " + Buffer.from(
              `${process.env.TWILIO_ACCOUNT_SID}:${process.env.TWILIO_AUTH_TOKEN}`
            ).toString("base64"),
            "Content-Type": "application/x-www-form-urlencoded"
          },
          body: new URLSearchParams({
            From: params.get("To"),
            // Our Twilio number
            To: from,
            // Send back to user
            Body: confirmationMessage
          })
        }
      );
      if (twilioResponse.ok) {
        console.log("\u2705 Confirmation SMS sent");
      } else {
        console.log("\u26A0\uFE0F  Failed to send confirmation SMS");
      }
      return {
        statusCode: 200,
        headers: {
          "Content-Type": "text/xml"
        },
        body: `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Message>\u2705 Bug received! Issue #${issue.number} created. Thank you!</Message>
</Response>`
      };
    } else {
      const error = await githubResponse.text();
      console.error("GitHub API error:", error);
      return {
        statusCode: 200,
        headers: {
          "Content-Type": "text/xml"
        },
        body: `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Message>\u274C Error creating bug. Please try again or contact support.</Message>
</Response>`
      };
    }
  } catch (error) {
    console.error("Error:", error);
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "text/xml"
      },
      body: `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Message>\u274C Error processing message. Please try again.</Message>
</Response>`
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
