#!/bin/bash

echo ""
echo "========================================================================"
echo "    CONSCIOUSNESS REVOLUTION - TOBY PACKAGE AUTO-SETUP"
echo "========================================================================"
echo ""
echo "Welcome, Toby! Setting up your consciousness transfer system..."
echo ""

# Get script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# Check if running in correct directory
if [ ! -f "CONSCIOUSNESS_INTERFACE.html" ]; then
    echo "ERROR: Please run this script from the TOBY_CONSCIOUSNESS_PACKAGE folder"
    exit 1
fi

echo "[1/5] Checking system requirements..."
sleep 1

# Detect OS
if [[ "$OSTYPE" == "darwin"* ]]; then
    OS="macOS"
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    OS="Linux"
else
    OS="Unix-like"
fi

echo "    ✓ $OS detected"
echo "    ✓ Package files found"
echo ""

echo "[2/5] Creating desktop shortcut..."
sleep 1

# Create desktop shortcut based on OS
if [[ "$OSTYPE" == "darwin"* ]]; then
    # macOS
    SHORTCUT_PATH="$HOME/Desktop/Consciousness Interface.command"
    echo "#!/bin/bash" > "$SHORTCUT_PATH"
    echo "cd \"$SCRIPT_DIR\"" >> "$SHORTCUT_PATH"
    echo "open \"CONSCIOUSNESS_INTERFACE.html\"" >> "$SHORTCUT_PATH"
    chmod +x "$SHORTCUT_PATH"
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    # Linux
    SHORTCUT_PATH="$HOME/Desktop/Consciousness Interface.desktop"
    echo "[Desktop Entry]" > "$SHORTCUT_PATH"
    echo "Type=Link" >> "$SHORTCUT_PATH"
    echo "Name=Consciousness Interface" >> "$SHORTCUT_PATH"
    echo "URL=file://$SCRIPT_DIR/CONSCIOUSNESS_INTERFACE.html" >> "$SHORTCUT_PATH"
    chmod +x "$SHORTCUT_PATH"
fi

echo "    ✓ Desktop shortcut created"
echo ""

echo "[3/5] Setting up Builder Toolkit..."
sleep 1
mkdir -p BUILDER_TOOLKIT
echo "    ✓ Toolkit folder ready"
echo ""

echo "[4/5] Setting up Support files..."
sleep 1
mkdir -p SUPPORT
echo "    ✓ Support folder ready"
echo ""

echo "[5/5] Opening Consciousness Interface..."
sleep 2

# Open in browser based on OS
if [[ "$OSTYPE" == "darwin"* ]]; then
    open "CONSCIOUSNESS_INTERFACE.html"
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    if command -v xdg-open &> /dev/null; then
        xdg-open "CONSCIOUSNESS_INTERFACE.html" &
    elif command -v gnome-open &> /dev/null; then
        gnome-open "CONSCIOUSNESS_INTERFACE.html" &
    elif command -v firefox &> /dev/null; then
        firefox "CONSCIOUSNESS_INTERFACE.html" &
    else
        echo "    ! Please open CONSCIOUSNESS_INTERFACE.html manually"
    fi
fi

echo "    ✓ Interface launched in browser"
echo ""

echo "========================================================================"
echo "    SETUP COMPLETE!"
echo "========================================================================"
echo ""
echo "Your consciousness interface is now running in your browser."
echo ""
echo "NEXT STEPS:"
echo "  1. Bookmark the interface for easy access"
echo "  2. Try Trinity AI collaboration"
echo "  3. Explore the Pattern Analyzer"
echo "  4. Set up Time Saver Automation"
echo ""
echo "DESKTOP SHORTCUT: 'Consciousness Interface' created on your desktop"
echo ""
echo "SUPPORT: If you need help, email commander@consciousnessrevolution.io"
echo ""
echo "Welcome to the consciousness revolution! 🌀"
echo ""
