// JARVIS Chrome Extension - Agent Side
// Connects to Mission Control and receives commands

class JARVISAgent {
  constructor() {
    this.ws = null;
    this.agentId = null;
    this.agentName = this.detectAgentName();
    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = 10;
    this.reconnectDelay = 3000;

    this.connect();
  }

  // Detect agent name from computer/browser
  detectAgentName() {
    // Try to get from Chrome storage first
    const stored = localStorage.getItem('jarvis_agent_name');
    if (stored) return stored;

    // Prompt user on first run
    const name = prompt('Enter your name for JARVIS Mission Control:', 'Agent');
    if (name) {
      localStorage.setItem('jarvis_agent_name', name);
      return name;
    }

    return 'Unknown Agent';
  }

  // Connect to Mission Control WebSocket
  connect() {
    console.log('🔗 Connecting to JARVIS Mission Control...');

    try {
      this.ws = new WebSocket('ws://localhost:8888');

      this.ws.onopen = () => {
        console.log('✅ Connected to Mission Control!');
        this.reconnectAttempts = 0;
        this.register();
        this.startStatusUpdates();
      };

      this.ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          this.handleMessage(data);
        } catch (err) {
          console.error('Error parsing message:', err);
        }
      };

      this.ws.onerror = (error) => {
        console.error('❌ WebSocket error:', error);
      };

      this.ws.onclose = () => {
        console.log('🔌 Disconnected from Mission Control');
        this.attemptReconnect();
      };

    } catch (err) {
      console.error('Failed to connect:', err);
      this.attemptReconnect();
    }
  }

  // Attempt to reconnect
  attemptReconnect() {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.error('Max reconnection attempts reached. Please restart JARVIS.');
      return;
    }

    this.reconnectAttempts++;
    console.log(`Reconnecting in ${this.reconnectDelay/1000}s... (Attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts})`);

    setTimeout(() => {
      this.connect();
    }, this.reconnectDelay);
  }

  // Register with Mission Control
  register() {
    this.send({
      type: 'REGISTER',
      name: this.agentName,
      userAgent: navigator.userAgent,
      timestamp: new Date().toISOString()
    });
  }

  // Send status updates periodically
  startStatusUpdates() {
    setInterval(() => {
      this.sendStatusUpdate();
    }, 5000); // Every 5 seconds
  }

  // Send current status
  sendStatusUpdate() {
    const activeApps = this.getActiveApps();
    const position = this.getCurrentPosition();

    this.send({
      type: 'STATUS_UPDATE',
      status: 'connected',
      position: position,
      activeApps: activeApps,
      url: window.location.href,
      timestamp: new Date().toISOString()
    });
  }

  // Get currently active JARVIS apps
  getActiveApps() {
    const apps = [];
    const leftSlots = document.querySelectorAll('#left-dock .dock-slot.active');
    const rightSlots = document.querySelectorAll('#right-dock .dock-slot.active');

    leftSlots.forEach(slot => {
      if (slot.dataset.app) apps.push(slot.dataset.app);
    });
    rightSlots.forEach(slot => {
      if (slot.dataset.app) apps.push(slot.dataset.app);
    });

    return apps;
  }

  // Get current Battleship grid position
  getCurrentPosition() {
    // If control overlay is active, return that position
    const overlay = document.getElementById('control-overlay');
    if (overlay && overlay.classList.contains('active')) {
      const coordDisplay = document.getElementById('control-coord');
      return coordDisplay ? coordDisplay.textContent : null;
    }

    // Otherwise, return general position
    return 'Active';
  }

  // Handle incoming messages from Mission Control
  handleMessage(data) {
    console.log('📨 Received from Mission Control:', data.type);

    switch (data.type) {
      case 'WELCOME':
        this.agentId = data.agentId;
        console.log(`✅ Registered as ${this.agentName} (${this.agentId})`);
        this.showNotification('Connected to Mission Control', 'success');
        break;

      case 'UPDATE':
        this.handleUpdate(data.updateData);
        break;

      case 'MESSAGE':
        this.showNotification(data.message, 'info', data.from);
        break;

      case 'CLICK':
        this.performClick(data.x, data.y);
        break;

      case 'CLICK_COORDINATE':
        this.performClickCoordinate(data.coordinate);
        break;

      case 'OPEN_APP':
        this.openApp(data.appId, data.position);
        break;

      case 'SCREEN_SHARE_REQUEST':
        this.handleScreenShareRequest();
        break;

      case 'CONTROL_REQUEST':
        this.handleControlRequest();
        break;

      case 'PING':
        this.send({ type: 'PONG' });
        break;

      default:
        console.log('Unknown message type:', data.type);
    }
  }

  // Handle update command
  handleUpdate(updateData) {
    console.log('🔄 Applying update:', updateData);
    this.showNotification('JARVIS update received', 'info');

    // Apply updates (could be new features, config changes, etc.)
    if (updateData.version) {
      localStorage.setItem('jarvis_version', updateData.version);
    }

    if (updateData.config) {
      Object.assign(window.JARVIS_CONFIG || {}, updateData.config);
    }

    // Reload if major update
    if (updateData.reload) {
      this.showNotification('Reloading JARVIS...', 'warning');
      setTimeout(() => location.reload(), 2000);
    }
  }

  // Perform click at coordinates
  performClick(x, y) {
    console.log(`🖱️ Clicking at (${x}, ${y})`);

    const element = document.elementFromPoint(x, y);
    if (element) {
      element.click();
      this.showNotification(`Clicked at (${x}, ${y})`, 'success');
    }
  }

  // Perform click using Battleship coordinates
  performClickCoordinate(coordinate) {
    console.log(`🎯 Clicking at Battleship coordinate: ${coordinate}`);

    // Parse coordinate (e.g., "B7")
    const row = coordinate.charCodeAt(0) - 65; // A=0, B=1, etc.
    const col = parseInt(coordinate.substring(1)) - 1; // 1=0, 2=1, etc.

    // Convert to screen coordinates
    const x = (col + 0.5) * (window.innerWidth / 10);
    const y = (row + 0.5) * (window.innerHeight / 10);

    // Show visual feedback
    this.showClickIndicator(x, y, coordinate);

    // Perform click
    setTimeout(() => {
      this.performClick(x, y);
    }, 500);
  }

  // Show visual click indicator
  showClickIndicator(x, y, label) {
    const indicator = document.createElement('div');
    indicator.style.cssText = `
      position: fixed;
      left: ${x}px;
      top: ${y}px;
      width: 40px;
      height: 40px;
      margin-left: -20px;
      margin-top: -20px;
      border: 3px solid #ef4444;
      border-radius: 50%;
      z-index: 999999;
      pointer-events: none;
      animation: jarvis-click-pulse 1s ease-out forwards;
    `;

    const labelEl = document.createElement('div');
    labelEl.textContent = label;
    labelEl.style.cssText = `
      position: absolute;
      top: -30px;
      left: 50%;
      transform: translateX(-50%);
      background: #ef4444;
      color: white;
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 12px;
      font-weight: bold;
      white-space: nowrap;
    `;
    indicator.appendChild(labelEl);

    document.body.appendChild(indicator);
    setTimeout(() => indicator.remove(), 1000);
  }

  // Open app at position
  openApp(appId, position) {
    console.log(`📱 Opening ${appId} on ${position}`);

    // Trigger app placement
    if (window.JARVIS_INTERFACE) {
      window.JARVIS_INTERFACE.placeApp(appId, position);
      this.showNotification(`Opened ${appId} on ${position}`, 'success');
    }
  }

  // Handle screen share request
  handleScreenShareRequest() {
    if (confirm('Commander is requesting screen share. Allow?')) {
      this.startScreenShare();
    } else {
      this.send({
        type: 'SCREEN_SHARE_DENIED',
        timestamp: new Date().toISOString()
      });
    }
  }

  // Start screen sharing
  startScreenShare() {
    console.log('📺 Starting screen share...');

    // Capture screen every 2 seconds
    this.screenShareInterval = setInterval(() => {
      this.captureScreen();
    }, 2000);

    this.send({
      type: 'SCREEN_SHARE_START',
      timestamp: new Date().toISOString()
    });

    this.showNotification('Screen sharing started', 'warning');
  }

  // Capture screen and send to Mission Control
  async captureScreen() {
    try {
      // Use html2canvas or similar to capture visible area
      // For now, just send metadata
      this.send({
        type: 'SCREEN_FRAME',
        frame: {
          url: window.location.href,
          title: document.title,
          timestamp: new Date().toISOString()
        }
      });
    } catch (err) {
      console.error('Screen capture error:', err);
    }
  }

  // Handle control request
  handleControlRequest() {
    if (confirm('Commander is requesting remote control. Allow?')) {
      this.enableRemoteControl();
    } else {
      this.send({
        type: 'CONTROL_DENIED',
        timestamp: new Date().toISOString()
      });
    }
  }

  // Enable remote control mode
  enableRemoteControl() {
    console.log('🎮 Remote control enabled');

    // Activate control overlay
    if (window.JARVIS_INTERFACE) {
      window.JARVIS_INTERFACE.activateControlMode();
    }

    this.send({
      type: 'CONTROL_ENABLED',
      timestamp: new Date().toISOString()
    });

    this.showNotification('Remote control enabled', 'warning', 'Commander');
  }

  // Show notification
  showNotification(message, type = 'info', from = null) {
    const notification = document.createElement('div');
    notification.className = `jarvis-notification jarvis-notification-${type}`;
    notification.innerHTML = `
      ${from ? `<strong>${from}:</strong> ` : ''}${message}
    `;

    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 15px 20px;
      background: ${type === 'success' ? '#22c55e' : type === 'warning' ? '#f59e0b' : type === 'error' ? '#ef4444' : '#3b82f6'};
      color: white;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      z-index: 999999;
      font-family: system-ui, sans-serif;
      font-size: 14px;
      max-width: 300px;
      animation: jarvis-slide-in 0.3s ease-out;
    `;

    document.body.appendChild(notification);

    setTimeout(() => {
      notification.style.animation = 'jarvis-slide-out 0.3s ease-out forwards';
      setTimeout(() => notification.remove(), 300);
    }, 5000);
  }

  // Send message to Mission Control
  send(data) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(data));
    } else {
      console.warn('WebSocket not connected. Message not sent:', data.type);
    }
  }
}

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
  @keyframes jarvis-slide-in {
    from {
      transform: translateX(400px);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }

  @keyframes jarvis-slide-out {
    from {
      transform: translateX(0);
      opacity: 1;
    }
    to {
      transform: translateX(400px);
      opacity: 0;
    }
  }

  @keyframes jarvis-click-pulse {
    0% {
      transform: scale(1);
      opacity: 1;
    }
    100% {
      transform: scale(3);
      opacity: 0;
    }
  }
`;
document.head.appendChild(style);

// Initialize JARVIS Agent when page loads
console.log('🤖 JARVIS Agent initializing...');
window.JARVIS_AGENT = new JARVISAgent();

console.log('✅ JARVIS Agent ready for Mission Control connection');
