// ╔════════════════════════════════════════════════════════════════╗
// ║           🤖 JARVIS VOICE-CONTROLLED DASHBOARD                 ║
// ║                   Content Script v1.0                          ║
// ╚════════════════════════════════════════════════════════════════╝

(function() {
  'use strict';

  // Create isolated container for JARVIS
  const jarvisRoot = document.createElement('div');
  jarvisRoot.id = 'jarvis-extension-root';
  document.body.appendChild(jarvisRoot);

  // Inject HTML structure
  jarvisRoot.innerHTML = `
    <!-- Voice Activation Button -->
    <button id="jarvis-voice-btn">🎤 Click to Speak</button>

    <!-- Voice Transcript Display -->
    <div id="jarvis-voice-transcript"></div>

    <!-- JARVIS Response -->
    <div id="jarvis-response" class="jarvis-response"></div>

    <!-- App Library Menu -->
    <div id="jarvis-app-library">
      <div class="library-header">
        <div class="library-title">📱 App Library</div>
        <button class="close-library" id="jarvis-close-library">✕ Close</button>
      </div>
      <div class="app-grid" id="jarvis-app-grid"></div>
    </div>

    <!-- Left Edge Dock -->
    <div id="jarvis-left-dock" class="jarvis-edge-dock">
      <div class="jarvis-dock-slot empty" data-slot="left-1"></div>
      <div class="jarvis-dock-slot empty" data-slot="left-2"></div>
      <div class="jarvis-dock-slot empty" data-slot="left-3"></div>
      <div class="jarvis-dock-slot empty" data-slot="left-4"></div>
    </div>

    <!-- Right Edge Dock -->
    <div id="jarvis-right-dock" class="jarvis-edge-dock">
      <div class="jarvis-dock-slot empty" data-slot="right-1"></div>
      <div class="jarvis-dock-slot empty" data-slot="right-2"></div>
      <div class="jarvis-dock-slot empty" data-slot="right-3"></div>
      <div class="jarvis-dock-slot empty" data-slot="right-4"></div>
    </div>

    <!-- Intelligent Terminal -->
    <div id="jarvis-intelligent-terminal">
      <div class="terminal-output" id="jarvis-terminal-output">
        <div class="terminal-line">JARVIS Intelligence Terminal v1.0</div>
        <div class="terminal-line">Type commands or speak naturally...</div>
        <div class="terminal-line">Example: "show terminal on left" or "open app library"</div>
      </div>
      <div class="terminal-input">
        <span class="terminal-prompt">JARVIS $</span>
        <input type="text" id="jarvis-terminal-cmd" placeholder="Type command or press ~ to toggle terminal...">
      </div>
    </div>
  `;

  // Available Apps
  const availableApps = [
    { id: 'terminal', icon: '💻', name: 'Terminal', desc: 'Command interface' },
    { id: 'music', icon: '🎵', name: 'Music', desc: 'Audio player' },
    { id: 'metrics', icon: '📊', name: 'Metrics', desc: 'Performance tracking' },
    { id: 'files', icon: '📁', name: 'Files', desc: 'File browser' },
    { id: 'team', icon: '👥', name: 'Team', desc: 'Team status' },
    { id: 'inbox', icon: '📬', name: 'Inbox', desc: 'Messages' },
    { id: 'chat', icon: '💬', name: 'Chat', desc: 'Conversations' },
    { id: 'control', icon: '🎯', name: 'Control', desc: 'Remote control' },
    { id: 'notes', icon: '📝', name: 'Notes', desc: 'Quick notes' },
    { id: 'browser', icon: '🌐', name: 'Browser', desc: 'Web browser' },
    { id: 'calendar', icon: '📅', name: 'Calendar', desc: 'Schedule' },
    { id: 'tasks', icon: '✅', name: 'Tasks', desc: 'Todo list' },
  ];

  // Current dock state
  const dockState = {
    'left-1': null,
    'left-2': null,
    'left-3': null,
    'left-4': null,
    'right-1': null,
    'right-2': null,
    'right-3': null,
    'right-4': null,
  };

  // Populate app library
  function populateAppLibrary() {
    const grid = jarvisRoot.querySelector('#jarvis-app-grid');
    grid.innerHTML = '';

    availableApps.forEach(app => {
      const card = document.createElement('div');
      card.className = 'app-card';
      card.draggable = true;
      card.dataset.appId = app.id;
      card.innerHTML = `
        <div class="app-icon">${app.icon}</div>
        <div class="app-name">${app.name}</div>
        <div class="app-desc">${app.desc}</div>
      `;

      card.addEventListener('dragstart', handleDragStart);
      card.addEventListener('dragend', handleDragEnd);

      grid.appendChild(card);
    });
  }

  // Drag and drop handlers
  let draggedApp = null;

  function handleDragStart(e) {
    draggedApp = this.dataset.appId;
    this.classList.add('dragging');
  }

  function handleDragEnd(e) {
    this.classList.remove('dragging');
  }

  // Setup dock slots
  jarvisRoot.querySelectorAll('.jarvis-dock-slot').forEach(slot => {
    slot.addEventListener('dragover', (e) => {
      e.preventDefault();
      slot.classList.add('drag-over');
    });

    slot.addEventListener('dragleave', () => {
      slot.classList.remove('drag-over');
    });

    slot.addEventListener('drop', (e) => {
      e.preventDefault();
      slot.classList.remove('drag-over');

      const slotId = slot.dataset.slot;
      const app = availableApps.find(a => a.id === draggedApp);

      if (app) {
        dockState[slotId] = app;
        renderDockSlot(slot, app);
        showJarvisResponse(`✅ ${app.name} added to ${slotId.includes('left') ? 'left' : 'right'} edge`);
      }
    });
  });

  function renderDockSlot(slot, app) {
    slot.classList.remove('empty');
    slot.innerHTML = `
      <div class="app-icon">${app.icon}</div>
      <div class="app-name">${app.name}</div>
    `;
  }

  // Voice Recognition
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

  if (!SpeechRecognition) {
    console.warn('⚠️ JARVIS: Speech recognition not supported in this browser');
  } else {
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.lang = 'en-US';

    const voiceBtn = jarvisRoot.querySelector('#jarvis-voice-btn');
    const voiceTranscript = jarvisRoot.querySelector('#jarvis-voice-transcript');

    voiceBtn.addEventListener('click', () => {
      if (voiceBtn.classList.contains('listening')) {
        recognition.stop();
      } else {
        recognition.start();
        voiceBtn.classList.add('listening');
        voiceBtn.textContent = '🎤 Listening...';
        voiceTranscript.classList.add('active');
        voiceTranscript.textContent = 'Listening for commands...';
      }
    });

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript.toLowerCase();
      voiceTranscript.textContent = `You said: "${transcript}"`;
      processVoiceCommand(transcript);
    };

    recognition.onend = () => {
      voiceBtn.classList.remove('listening');
      voiceBtn.textContent = '🎤 Click to Speak';
      setTimeout(() => {
        voiceTranscript.classList.remove('active');
      }, 3000);
    };

    recognition.onerror = (event) => {
      console.error('JARVIS Voice Recognition Error:', event.error);
      voiceBtn.classList.remove('listening');
      voiceBtn.textContent = '🎤 Click to Speak';
      showJarvisResponse('❌ Voice recognition error: ' + event.error);
    };
  }

  // Process voice commands
  function processVoiceCommand(command) {
    addTerminalLine(`Voice: ${command}`);

    // App library commands
    if (command.includes('open app') || command.includes('show app') || command.includes('app library')) {
      openAppLibrary();
      showJarvisResponse('📱 Opening app library');
    }
    // Hide/show commands
    else if (command.includes('hide everything') || command.includes('hide all')) {
      jarvisRoot.querySelector('#jarvis-left-dock').style.display = 'none';
      jarvisRoot.querySelector('#jarvis-right-dock').style.display = 'none';
      showJarvisResponse('✅ Everything hidden');
    }
    else if (command.includes('show everything') || command.includes('show all')) {
      jarvisRoot.querySelector('#jarvis-left-dock').style.display = 'flex';
      jarvisRoot.querySelector('#jarvis-right-dock').style.display = 'flex';
      showJarvisResponse('✅ Everything visible');
    }
    // Terminal toggle
    else if (command.includes('terminal') || command.includes('open terminal')) {
      toggleTerminal();
      showJarvisResponse('💻 Terminal toggled');
    }
    // App placement commands
    else if (command.includes('put') || command.includes('add') || command.includes('show')) {
      handleAppPlacementCommand(command);
    }
    else {
      showJarvisResponse('❓ Command not recognized. Try "open app library" or "put terminal on left"');
    }
  }

  function handleAppPlacementCommand(command) {
    const app = availableApps.find(a => command.includes(a.name.toLowerCase()));
    const side = command.includes('left') ? 'left' : command.includes('right') ? 'right' : null;

    if (app && side) {
      // Find first empty slot on that side
      const emptySlot = Object.keys(dockState).find(key =>
        key.startsWith(side) && dockState[key] === null
      );

      if (emptySlot) {
        dockState[emptySlot] = app;
        const slotElement = jarvisRoot.querySelector(`[data-slot="${emptySlot}"]`);
        renderDockSlot(slotElement, app);
        showJarvisResponse(`✅ ${app.name} added to ${side} edge`);
        addTerminalLine(`Added ${app.name} to ${side} edge`);
      } else {
        showJarvisResponse(`❌ No empty slots on ${side} edge`);
      }
    }
  }

  // App Library functions
  function openAppLibrary() {
    jarvisRoot.querySelector('#jarvis-app-library').classList.add('active');
  }

  function closeAppLibrary() {
    jarvisRoot.querySelector('#jarvis-app-library').classList.remove('active');
  }

  // Terminal functions
  function toggleTerminal() {
    jarvisRoot.querySelector('#jarvis-intelligent-terminal').classList.toggle('active');
  }

  function addTerminalLine(text) {
    const output = jarvisRoot.querySelector('#jarvis-terminal-output');
    const line = document.createElement('div');
    line.className = 'terminal-line';
    line.textContent = `$ ${text}`;
    output.appendChild(line);
    output.scrollTop = output.scrollHeight;
  }

  // Terminal input
  jarvisRoot.querySelector('#jarvis-terminal-cmd').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      const cmd = e.target.value;
      processVoiceCommand(cmd);
      e.target.value = '';
    }
  });

  // JARVIS response display
  function showJarvisResponse(message) {
    const response = jarvisRoot.querySelector('#jarvis-response');
    response.textContent = message;
    response.classList.add('active');
    setTimeout(() => {
      response.classList.remove('active');
    }, 3000);
  }

  // Close library button
  jarvisRoot.querySelector('#jarvis-close-library').addEventListener('click', closeAppLibrary);

  // Keyboard shortcuts
  document.addEventListener('keydown', (e) => {
    // ~ key to toggle terminal
    if (e.key === '`' || e.key === '~') {
      e.preventDefault();
      toggleTerminal();
    }
    // Escape to close app library
    if (e.key === 'Escape') {
      closeAppLibrary();
    }
    // Ctrl+Space to activate voice (handled by extension commands, but also support direct)
    if (e.ctrlKey && e.key === ' ') {
      e.preventDefault();
      const voiceBtn = jarvisRoot.querySelector('#jarvis-voice-btn');
      if (voiceBtn) voiceBtn.click();
    }
  });

  // Listen for extension commands
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'toggleVoice') {
      const voiceBtn = jarvisRoot.querySelector('#jarvis-voice-btn');
      if (voiceBtn) voiceBtn.click();
    } else if (request.action === 'toggleLeftDock') {
      const leftDock = jarvisRoot.querySelector('#jarvis-left-dock');
      leftDock.style.display = leftDock.style.display === 'none' ? 'flex' : 'none';
    } else if (request.action === 'toggleRightPanel') {
      const rightDock = jarvisRoot.querySelector('#jarvis-right-dock');
      rightDock.style.display = rightDock.style.display === 'none' ? 'flex' : 'none';
    } else if (request.action === 'hideAll') {
      jarvisRoot.querySelector('#jarvis-left-dock').style.display = 'none';
      jarvisRoot.querySelector('#jarvis-right-dock').style.display = 'none';
      showJarvisResponse('✅ Everything hidden');
    } else if (request.action === 'showAll') {
      jarvisRoot.querySelector('#jarvis-left-dock').style.display = 'flex';
      jarvisRoot.querySelector('#jarvis-right-dock').style.display = 'flex';
      showJarvisResponse('✅ Everything visible');
    }
    sendResponse({ success: true });
  });

  // Initialize
  populateAppLibrary();

  // Load Mission Control agent (connects to remote management)
  const agentScript = document.createElement('script');
  agentScript.src = chrome.runtime.getURL('jarvis-agent.js');
  document.head.appendChild(agentScript);

  console.log(`
╔════════════════════════════════════════════════════════════════╗
║           🎤 JARVIS VOICE-CONTROLLED DASHBOARD                 ║
╠════════════════════════════════════════════════════════════════╣
║                                                                ║
║  Voice Commands:                                               ║
║  • "Open app library" - Show all apps                         ║
║  • "Put terminal on left" - Add app to edge                   ║
║  • "Show music on right" - Add app to edge                    ║
║  • "Hide everything" - Collapse all                           ║
║  • "Show everything" - Expand all                             ║
║  • "Open terminal" - Toggle intelligent terminal              ║
║                                                                ║
║  Keyboard:                                                     ║
║  • ~ - Toggle terminal                                        ║
║  • Ctrl+Space - Voice activation                              ║
║  • Escape - Close app library                                 ║
║                                                                ║
║  Drag & Drop:                                                  ║
║  • Drag apps from library to edge slots                       ║
║                                                                ║
║  Status: ACTIVE on ${window.location.hostname}                ║
║                                                                ║
╚════════════════════════════════════════════════════════════════╝
  `);

})();
