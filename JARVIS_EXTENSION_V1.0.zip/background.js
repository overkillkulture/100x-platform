// JARVIS Background Service Worker
// Handles keyboard shortcuts and extension lifecycle

chrome.runtime.onInstalled.addListener(() => {
  console.log('🤖 JARVIS Extension installed!');
});

// Listen for keyboard commands
chrome.commands.onCommand.addListener((command) => {
  console.log('Command received:', command);

  // Send message to active tab
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, { command: command }, (response) => {
        if (chrome.runtime.lastError) {
          console.error('Error sending message:', chrome.runtime.lastError);
        } else {
          console.log('Command sent successfully:', response);
        }
      });
    }
  });
});

// Handle extension icon click
chrome.action.onClicked.addListener((tab) => {
  chrome.tabs.sendMessage(tab.id, { command: 'toggle-all' });
});
