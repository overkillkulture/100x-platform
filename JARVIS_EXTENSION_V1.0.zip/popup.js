﻿// JARVIS Extension Popup

function openMissionControl() {
  chrome.tabs.create({ url: 'http://localhost:8888/dashboard' });
}

function reloadExtension() {
  chrome.runtime.reload();
}

function showHelp() {
  alert('JARVIS Voice Commands:\n\n' +
        '• "Open app library"\n' +
        '• "Put terminal on left"\n' +
        '• "Show music on right"\n' +
        '• "Hide everything"\n\n' +
        'Keyboard Shortcuts:\n\n' +
        '• Ctrl+Space - Voice\n' +
        '• ~ - Terminal\n' +
        '• Escape - Close');
}

// Check Mission Control connection
fetch('http://localhost:8888/api/agents')
  .then(() => {
    document.getElementById('status').textContent = 'Connected to Mission Control';
    document.getElementById('status').className = 'status-online';
  })
  .catch(() => {
    document.getElementById('status').textContent = 'Mission Control Offline';
    document.getElementById('status').className = 'status-offline';
  });
